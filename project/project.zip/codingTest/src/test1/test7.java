package test1;

import java.util.Scanner;

public class test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "";
		Scanner scan = new Scanner(System.in);
		while(scan.hasNext()) {
			str=scan.nextLine();
			System.out.println(str);
		}
		
	}
}
