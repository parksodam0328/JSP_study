package test1;


public class test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(5);
		System.out.println("parksodam");
	}

}
