package test1;


public class test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("강한친구 대한육군");
		System.out.println("강한친구 대한육군");
	}
}
