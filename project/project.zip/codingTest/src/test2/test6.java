package test2;

import java.util.Scanner;

public class test6 {

	public static void main(String[] args) {
		int a=0,b=0,c=0;
		Scanner scan = new Scanner(System.in);
		
		a = scan.nextInt();
		b = scan.nextInt();
		if(a>=1 && b<=10000) {
			
		}
		
	}

}
